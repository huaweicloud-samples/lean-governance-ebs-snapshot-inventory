# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AgencyAssumedby:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'user': 'AgencyAssumedbyUser'
    }

    attribute_map = {
        'user': 'user'
    }

    def __init__(self, user=None):
        r"""AgencyAssumedby

        The model defined in huaweicloud sdk

        :param user: 
        :type user: :class:`huaweicloudsdkiam.v3.AgencyAssumedbyUser`
        """
        
        

        self._user = None
        self.discriminator = None

        self.user = user

    @property
    def user(self):
        r"""Gets the user of this AgencyAssumedby.

        :return: The user of this AgencyAssumedby.
        :rtype: :class:`huaweicloudsdkiam.v3.AgencyAssumedbyUser`
        """
        return self._user

    @user.setter
    def user(self, user):
        r"""Sets the user of this AgencyAssumedby.

        :param user: The user of this AgencyAssumedby.
        :type user: :class:`huaweicloudsdkiam.v3.AgencyAssumedbyUser`
        """
        self._user = user

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AgencyAssumedby):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
