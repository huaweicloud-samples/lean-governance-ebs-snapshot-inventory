# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AllowVpcEndpointsResult:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'description': 'str',
        'vpc_endpoint_id': 'str'
    }

    attribute_map = {
        'description': 'description',
        'vpc_endpoint_id': 'vpc_endpoint_id'
    }

    def __init__(self, description=None, vpc_endpoint_id=None):
        r"""AllowVpcEndpointsResult

        The model defined in huaweicloud sdk

        :param description: 描述信息。
        :type description: str
        :param vpc_endpoint_id: VPC端点，例如：8di3jdu38d7jhfa7df68adyfiadfia6d。
        :type vpc_endpoint_id: str
        """
        
        

        self._description = None
        self._vpc_endpoint_id = None
        self.discriminator = None

        self.description = description
        self.vpc_endpoint_id = vpc_endpoint_id

    @property
    def description(self):
        r"""Gets the description of this AllowVpcEndpointsResult.

        描述信息。

        :return: The description of this AllowVpcEndpointsResult.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this AllowVpcEndpointsResult.

        描述信息。

        :param description: The description of this AllowVpcEndpointsResult.
        :type description: str
        """
        self._description = description

    @property
    def vpc_endpoint_id(self):
        r"""Gets the vpc_endpoint_id of this AllowVpcEndpointsResult.

        VPC端点，例如：8di3jdu38d7jhfa7df68adyfiadfia6d。

        :return: The vpc_endpoint_id of this AllowVpcEndpointsResult.
        :rtype: str
        """
        return self._vpc_endpoint_id

    @vpc_endpoint_id.setter
    def vpc_endpoint_id(self, vpc_endpoint_id):
        r"""Sets the vpc_endpoint_id of this AllowVpcEndpointsResult.

        VPC端点，例如：8di3jdu38d7jhfa7df68adyfiadfia6d。

        :param vpc_endpoint_id: The vpc_endpoint_id of this AllowVpcEndpointsResult.
        :type vpc_endpoint_id: str
        """
        self._vpc_endpoint_id = vpc_endpoint_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AllowVpcEndpointsResult):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
