# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateSnapshotRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'snapshot_id': 'str',
        'body': 'UpdateSnapshotRequestBody'
    }

    attribute_map = {
        'snapshot_id': 'snapshot_id',
        'body': 'body'
    }

    def __init__(self, snapshot_id=None, body=None):
        r"""UpdateSnapshotRequest

        The model defined in huaweicloud sdk

        :param snapshot_id: 快照ID
        :type snapshot_id: str
        :param body: Body of the UpdateSnapshotRequest
        :type body: :class:`huaweicloudsdkevs.v2.UpdateSnapshotRequestBody`
        """
        
        

        self._snapshot_id = None
        self._body = None
        self.discriminator = None

        self.snapshot_id = snapshot_id
        if body is not None:
            self.body = body

    @property
    def snapshot_id(self):
        r"""Gets the snapshot_id of this UpdateSnapshotRequest.

        快照ID

        :return: The snapshot_id of this UpdateSnapshotRequest.
        :rtype: str
        """
        return self._snapshot_id

    @snapshot_id.setter
    def snapshot_id(self, snapshot_id):
        r"""Sets the snapshot_id of this UpdateSnapshotRequest.

        快照ID

        :param snapshot_id: The snapshot_id of this UpdateSnapshotRequest.
        :type snapshot_id: str
        """
        self._snapshot_id = snapshot_id

    @property
    def body(self):
        r"""Gets the body of this UpdateSnapshotRequest.

        :return: The body of this UpdateSnapshotRequest.
        :rtype: :class:`huaweicloudsdkevs.v2.UpdateSnapshotRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this UpdateSnapshotRequest.

        :param body: The body of this UpdateSnapshotRequest.
        :type body: :class:`huaweicloudsdkevs.v2.UpdateSnapshotRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateSnapshotRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
