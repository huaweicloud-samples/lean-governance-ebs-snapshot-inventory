# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CinderAcceptVolumeTransferRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'transfer_id': 'str',
        'body': 'CinderAcceptVolumeTransferRequestBody'
    }

    attribute_map = {
        'transfer_id': 'transfer_id',
        'body': 'body'
    }

    def __init__(self, transfer_id=None, body=None):
        r"""CinderAcceptVolumeTransferRequest

        The model defined in huaweicloud sdk

        :param transfer_id: 云硬盘ID
        :type transfer_id: str
        :param body: Body of the CinderAcceptVolumeTransferRequest
        :type body: :class:`huaweicloudsdkevs.v2.CinderAcceptVolumeTransferRequestBody`
        """
        
        

        self._transfer_id = None
        self._body = None
        self.discriminator = None

        self.transfer_id = transfer_id
        if body is not None:
            self.body = body

    @property
    def transfer_id(self):
        r"""Gets the transfer_id of this CinderAcceptVolumeTransferRequest.

        云硬盘ID

        :return: The transfer_id of this CinderAcceptVolumeTransferRequest.
        :rtype: str
        """
        return self._transfer_id

    @transfer_id.setter
    def transfer_id(self, transfer_id):
        r"""Sets the transfer_id of this CinderAcceptVolumeTransferRequest.

        云硬盘ID

        :param transfer_id: The transfer_id of this CinderAcceptVolumeTransferRequest.
        :type transfer_id: str
        """
        self._transfer_id = transfer_id

    @property
    def body(self):
        r"""Gets the body of this CinderAcceptVolumeTransferRequest.

        :return: The body of this CinderAcceptVolumeTransferRequest.
        :rtype: :class:`huaweicloudsdkevs.v2.CinderAcceptVolumeTransferRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this CinderAcceptVolumeTransferRequest.

        :param body: The body of this CinderAcceptVolumeTransferRequest.
        :type body: :class:`huaweicloudsdkevs.v2.CinderAcceptVolumeTransferRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CinderAcceptVolumeTransferRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
